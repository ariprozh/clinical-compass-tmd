/**
 * Клинический Компас: Google Apps Script для приёма анкет (основной сайт + пациентский портал).
 * Вставьте этот код целиком вместо старого (Расширения → Apps Script), затем
 * Начать развёртывание → Управление развёртываниями → карандаш → Версия: Новая версия → Развернуть.
 * URL веб-приложения при этом НЕ меняется.
 */
const SHEET_NAME = 'DC_TMD_AxisII_Data';
const STATS_SHEET = 'Статистика';
// Задайте свой секретный ключ: он нужен для выдачи статистики по ссылке ?action=stats&key=...
const ADMIN_KEY = 'ЗАМЕНИТЕ_НА_СВОЙ_КЛЮЧ';

const HEADERS = [
  'record_uuid','assessment_datetime','participant_id','visit_id',
  'consent_status','consent_timestamp','age_18_plus','acute_trauma_exclusion',
  'gcps_now','gcps_worst','gcps_avg','gcps_cpi_0_100',
  'gcps_interf_daily','gcps_interf_social','gcps_interf_work','gcps_interf_mean_0_100',
  'pain_drawing_count','pain_drawing_zones',
  'jfls8_mean_0_10','jfls8_answered_count','jfls8_items_json',
  'phq4_total_0_12','phq4_anxiety_0_6','phq4_depression_0_6','safety_flag',
  'treatment_change','treatment_notes','missing_status','instrument_version','source'
];
const ZONES = ['TMJ_R','TMJ_L','Masseter_R','Masseter_L','Temporalis_R','Temporalis_L',
               'Ear_R','Ear_L','Chin','Neck_R','Neck_L'];

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

function getOrCreateSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) sheet = ss.insertSheet(SHEET_NAME);
  // Дописываем недостающие заголовки (например, новый столбец source), старые данные не трогаем
  const have = sheet.getLastColumn() ? sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0] : [];
  if (have.length < HEADERS.length) {
    sheet.getRange(1, 1, 1, HEADERS.length).setValues([HEADERS])
      .setFontWeight('bold').setBackground('#e0effe');
    sheet.setFrozenRows(1);
  }
  return sheet;
}

// Защита от формул: текст, начинающийся с = + - @, записывается как обычный текст
function safe_(v) {
  if (typeof v !== 'string') return v;
  return /^[=+\-@]/.test(v) ? "'" + v : v;
}

function doGet(e) {
  const p = (e && e.parameter) || {};
  if (p.action === 'stats') {
    if (p.key !== ADMIN_KEY) return json_({ status: 'error', message: 'Нет доступа' });
    return json_({ status: 'ok', stats: collectStats_() });
  }
  getOrCreateSheet();
  return json_({ status: 'ok', message: 'Клинический Компас: скрипт активен.' });
}

function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    const data = JSON.parse((e.postData && e.postData.contents) || '{}');
    if (data.action === 'ping') {
      return json_({ status: 'ok', message: 'Соединение с Google Таблицей установлено.' });
    }
    if (!data.participant_id || data.consent_status !== 'SIGNED') {
      return json_({ status: 'error', message: 'Нет кода участника или подписанного согласия' });
    }
    // Очередь: до 150 одновременных анкет записываются по одной и не затирают друг друга
    lock.waitLock(30000);
    const sheet = getOrCreateSheet();
    const uuid = data.record_uuid || Utilities.getUuid();

    // Повторная отправка той же анкеты (повтор при плохой связи) не создаёт дубль
    const last = sheet.getLastRow();
    if (last > 1) {
      const found = sheet.getRange(2, 1, last - 1, 1).createTextFinder(uuid).matchEntireCell(true).findNext();
      if (found) return json_({ status: 'duplicate', record_uuid: uuid, row_number: found.getRow() });
    }

    const row = [
      uuid,
      data.assessment_datetime || new Date().toISOString(),
      safe_(String(data.participant_id).slice(0, 60)),
      safe_(data.visit_id || ''),
      data.consent_status || '',
      data.consent_timestamp || '',
      data.age_18_plus ? 'YES' : 'NO',
      data.acute_trauma_exclusion || '',
      data.gcps?.pain_now ?? '', data.gcps?.pain_worst ?? '', data.gcps?.pain_avg ?? '', data.gcps?.cpi_0_100 ?? '',
      data.gcps?.interf_daily ?? '', data.gcps?.interf_social ?? '', data.gcps?.interf_work ?? '', data.gcps?.interf_mean_0_100 ?? '',
      data.pain_drawing_count ?? 0,
      Array.isArray(data.pain_drawing_zones) ? data.pain_drawing_zones.join('; ') : '',
      data.jfls8?.mean_0_10 ?? '', data.jfls8?.answered_count ?? '', JSON.stringify(data.jfls8?.items || {}),
      data.phq4?.total_0_12 ?? '', data.phq4?.anxiety_0_6 ?? '', data.phq4?.depression_0_6 ?? '',
      data.phq4?.safety_flag ? 'ALERT_REVIEW' : 'NORMAL',
      data.treatment_change || '',
      safe_(String(data.treatment_notes || '').slice(0, 2000)),
      data.missing_status || '',
      data.instrument_version || 'DC-TMD-AxisII-v1.2',
      data.source || 'main_site'
    ];
    sheet.appendRow(row);
    SpreadsheetApp.flush();
    return json_({ status: 'success', record_uuid: uuid, row_number: sheet.getLastRow() });
  } catch (err) {
    return json_({ status: 'error', message: String(err) });
  } finally {
    try { lock.releaseLock(); } catch (x) {}
  }
}

// ---------- Статистика для врача/исследователя ----------

function onOpen() {
  SpreadsheetApp.getUi().createMenu('Клинический Компас')
    .addItem('Создать / обновить лист «Статистика»', 'setupStats')
    .addItem('Сформировать отчёт в Google Документе', 'createDocReport')
    .addToUi();
}

function collectStats_() {
  const sheet = getOrCreateSheet();
  const n = Math.max(sheet.getLastRow() - 1, 0);
  const out = { total: n, patient_portal: 0, alerts: 0, participants: 0, avg: {} };
  if (!n) return out;
  const rows = sheet.getRange(2, 1, n, HEADERS.length).getValues();
  const col = name => HEADERS.indexOf(name);
  const ids = new Set();
  const sums = { cpi: [0,0], interf: [0,0], jfls: [0,0], phq: [0,0] };
  const add = (k, v) => { if (typeof v === 'number') { sums[k][0] += v; sums[k][1]++; } };
  rows.forEach(r => {
    ids.add(r[col('participant_id')]);
    if (r[col('source')] === 'patient_portal') out.patient_portal++;
    if (r[col('safety_flag')] === 'ALERT_REVIEW') out.alerts++;
    add('cpi', r[col('gcps_cpi_0_100')]); add('interf', r[col('gcps_interf_mean_0_100')]);
    add('jfls', r[col('jfls8_mean_0_10')]); add('phq', r[col('phq4_total_0_12')]);
  });
  out.participants = ids.size;
  Object.keys(sums).forEach(k => out.avg[k] = sums[k][1] ? Math.round(sums[k][0] / sums[k][1] * 100) / 100 : null);
  return out;
}

function setupStats() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  getOrCreateSheet();
  let st = ss.getSheetByName(STATS_SHEET);
  if (st) st.clear(); else st = ss.insertSheet(STATS_SHEET);
  const D = SHEET_NAME;
  const rows = [
    ['Показатель', 'Значение'],
    ['Всего анкет',                          `=COUNTA(${D}!A2:A)`],
    ['Уникальных участников',                `=IFERROR(COUNTA(UNIQUE(${D}!C2:C)),0)`],
    ['Анкет через пациентский портал',       `=COUNTIF(${D}!AD2:AD,"patient_portal")`],
    ['Требуют внимания врача (PHQ-4)',       `=COUNTIF(${D}!Y2:Y,"ALERT_REVIEW")`],
    ['Средний CPI боли (0-100)',             `=IFERROR(ROUND(AVERAGE(${D}!L2:L),1),"—")`],
    ['Среднее влияние боли (0-100)',         `=IFERROR(ROUND(AVERAGE(${D}!P2:P),1),"—")`],
    ['Средний JFLS-8 (0-10)',                `=IFERROR(ROUND(AVERAGE(${D}!S2:S),2),"—")`],
    ['Средний PHQ-4 (0-12)',                 `=IFERROR(ROUND(AVERAGE(${D}!V2:V),2),"—")`],
    ['Средняя тревога (0-6)',                `=IFERROR(ROUND(AVERAGE(${D}!W2:W),2),"—")`],
    ['Средняя депрессия (0-6)',              `=IFERROR(ROUND(AVERAGE(${D}!X2:X),2),"—")`]
  ];
  st.getRange(1, 1, rows.length, 2).setValues(rows);
  st.getRange(1, 1, 1, 2).setFontWeight('bold').setBackground('#e0effe');

  st.getRange('D1:E1').setValues([['Зона боли', 'Сколько анкет']]).setFontWeight('bold').setBackground('#e0effe');
  st.getRange(2, 4, ZONES.length, 2).setFormulas(ZONES.map((z, i) =>
    [z, `=COUNTIF(${D}!R2:R,"*${z}*")`]));

  st.getRange('G1').setValue('Анкет по дням').setFontWeight('bold').setBackground('#e0effe');
  st.getRange('G2').setFormula(
    `=IFERROR(QUERY({ARRAYFORMULA(LEFT(${D}!B2:B,10))},"select Col1, count(Col1) where Col1 <> '' group by Col1 order by Col1 label Col1 'Дата', count(Col1) 'Анкет'",0),"")`);

  st.setColumnWidths(1, 1, 280); st.setColumnWidths(4, 2, 130); st.setColumnWidths(7, 2, 110);
  st.getCharts().forEach(c => st.removeChart(c));
  st.insertChart(st.newChart().setChartType(Charts.ChartType.BAR)
    .addRange(st.getRange(1, 4, ZONES.length + 1, 2))
    .setOption('title', 'Локализация боли').setOption('legend', { position: 'none' })
    .setPosition(14, 1, 0, 0).build());
  SpreadsheetApp.getUi().alert('Лист «Статистика» создан. Данные обновляются автоматически.');
}

function createDocReport() {
  const s = collectStats_();
  const doc = DocumentApp.create('Клинический Компас: сводка ' + new Date().toLocaleDateString('ru-RU'));
  const b = doc.getBody();
  b.appendParagraph('Клинический Компас: сводка по анкетам').setHeading(DocumentApp.ParagraphHeading.HEADING1);
  b.appendParagraph('Сформировано: ' + new Date().toLocaleString('ru-RU'));
  [
    ['Всего анкет', s.total], ['Уникальных участников', s.participants],
    ['Через пациентский портал', s.patient_portal], ['Требуют внимания врача (PHQ-4)', s.alerts],
    ['Средний CPI боли (0-100)', s.avg.cpi], ['Среднее влияние боли (0-100)', s.avg.interf],
    ['Средний JFLS-8 (0-10)', s.avg.jfls], ['Средний PHQ-4 (0-12)', s.avg.phq]
  ].forEach(r => b.appendListItem(r[0] + ': ' + (r[1] === null ? '—' : r[1])));
  b.appendParagraph('Сводка носит исследовательский характер и не является диагнозом.').setItalic(true);
  doc.saveAndClose();
  SpreadsheetApp.getUi().alert('Отчёт создан: ' + doc.getUrl());
}
